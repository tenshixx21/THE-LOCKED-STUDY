# The Locked Study

A single-file interactive mystery game.

## Put it on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/root`, then save.
6. GitHub will give you a website link.

The evidence "photos" are stylized in-game placeholders so the game works without external image hosting. You can replace each `.photo` box with an `<img src="...">` later if you want to use generated evidence images.
